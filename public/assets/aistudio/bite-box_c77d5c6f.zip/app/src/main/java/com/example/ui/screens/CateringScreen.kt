package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BiteBoxMustard
import com.example.ui.theme.BiteBoxMustardDark
import com.example.ui.theme.BiteBoxRed
import com.example.ui.theme.BiteBoxRedContainer

@Composable
fun CateringScreen(
    onRequestQuoteWhatsApp: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var guestCount by remember { mutableFloatStateOf(30f) }
    var selectedEventType by remember { mutableStateOf("Birthday Party") }
    var selectedPackageIndex by remember { mutableIntStateOf(1) }
    var eventDate by remember { mutableStateOf("") }
    var eventLocation by remember { mutableStateOf("Islamabad") }

    val eventTypes = listOf("Birthday Party", "Corporate Lunch", "Game Night", "College Gathering")

    val packages = listOf(
        Triple("Classic Crunch Box", 850, "Zinger sliders, mini loaded fries & cold drinks"),
        Triple("Smash & Loaded Deluxe", 1150, "Full beef smash burgers, loaded fries & dips"),
        Triple("VIP Bite Box Feast", 1550, "Burgers, wings, loaded curly fries & molten lava cakes")
    )

    val currentPackage = packages[selectedPackageIndex]
    val estimatedTotal = (guestCount.toInt() * currentPackage.second)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .testTag("catering_screen")
    ) {
        // Hero Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_combo_deal),
                contentDescription = "Bite Box Catering",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.5f), Color.Black.copy(alpha = 0.85f))
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BiteBoxMustard
                ) {
                    Text(
                        text = "EVENT MEALS & CATERING",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Make Your Event Sizzle",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Hot gourmet boxes delivered fresh across Islamabad & Rawalpindi.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Quote Calculator
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Instant Quote Calculator",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BiteBoxRed
                    )
                    Text(
                        text = "Customize your menu package & guest count",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Event Type Chips
                    Text(
                        text = "Event Type",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        eventTypes.take(2).forEach { type ->
                            FilterChip(
                                selected = selectedEventType == type,
                                onClick = { selectedEventType = type },
                                label = { Text(type, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = BiteBoxRedContainer),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        eventTypes.drop(2).forEach { type ->
                            FilterChip(
                                selected = selectedEventType == type,
                                onClick = { selectedEventType = type },
                                label = { Text(type, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = BiteBoxRedContainer),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Guest count slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Estimated Guests",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${guestCount.toInt()} People",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = BiteBoxRed
                        )
                    }

                    Slider(
                        value = guestCount,
                        onValueChange = { guestCount = it },
                        valueRange = 10f..200f,
                        steps = 18,
                        colors = SliderDefaults.colors(
                            thumbColor = BiteBoxRed,
                            activeTrackColor = BiteBoxRed
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Packages
                    Text(
                        text = "Select Catering Package",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    packages.forEachIndexed { index, pkg ->
                        val isSelected = selectedPackageIndex == index
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) BiteBoxRedContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            onClick = { selectedPackageIndex = index }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = pkg.first,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) BiteBoxRed else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = pkg.third,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp
                                    )
                                }
                                Text(
                                    text = "Rs. ${pkg.second}/pax",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BiteBoxRed
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Date & Location
                    OutlinedTextField(
                        value = eventDate,
                        onValueChange = { eventDate = it },
                        label = { Text("Event Date & Time") },
                        placeholder = { Text("e.g. Next Saturday, 7:00 PM") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(14.dp))

                    // Total Calculation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Estimated Budget", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "Rs. $estimatedTotal",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = BiteBoxRed
                            )
                        }

                        Button(
                            onClick = {
                                val msg = StringBuilder()
                                msg.append("🎉 *Bite Box Catering Quote Request*\n")
                                msg.append("━━━━━━━━━━━━━━━━━━\n")
                                msg.append("🎯 *Event:* $selectedEventType\n")
                                msg.append("👥 *Guests:* ${guestCount.toInt()} pax\n")
                                msg.append("📦 *Package:* ${currentPackage.first} (Rs. ${currentPackage.second}/pax)\n")
                                if (eventDate.isNotBlank()) msg.append("📅 *Date:* $eventDate\n")
                                msg.append("📍 *Location:* $eventLocation\n")
                                msg.append("💰 *Est. Total:* Rs. $estimatedTotal\n")
                                msg.append("━━━━━━━━━━━━━━━━━━\n")
                                msg.append("Please provide formal quote & confirm booking.")

                                onRequestQuoteWhatsApp(msg.toString())
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("catering_request_quote_button")
                        ) {
                            Icon(imageVector = Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Request Quote", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Why Bite Box Catering
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = "The Bite Box Catering Promise",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            CateringPerkItem(
                icon = Icons.Default.LocalShipping,
                title = "Thermal Insulated Delivery",
                desc = "Burgers arrive steaming hot with crispy fries, packed in custom double-insulated food boxes."
            )
            Spacer(modifier = Modifier.height(8.dp))
            CateringPerkItem(
                icon = Icons.Default.Verified,
                title = "Live Fry Station Option",
                desc = "For parties over 50 pax, we can set up live loaded fries and hot sauce stations on-site."
            )
            Spacer(modifier = Modifier.height(8.dp))
            CateringPerkItem(
                icon = Icons.Default.Group,
                title = "Dedicated Event Coordinator",
                desc = "Direct WhatsApp communication with our head kitchen manager from start to finish."
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
private fun CateringPerkItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(BiteBoxRedContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = BiteBoxRed, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text(text = desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }
    }
}
