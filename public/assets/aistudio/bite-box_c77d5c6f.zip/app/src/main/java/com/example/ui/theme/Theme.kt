package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = BiteBoxRedLight,
    onPrimary = Color.White,
    primaryContainer = BiteBoxRedDark,
    onPrimaryContainer = BiteBoxRedContainer,
    secondary = BiteBoxMustard,
    onSecondary = Color.Black,
    secondaryContainer = BiteBoxMustardDark,
    onSecondaryContainer = BiteBoxMustardLight,
    tertiary = BiteBoxMustardLight,
    onTertiary = Color.Black,
    background = NeutralDark,
    onBackground = TextPrimaryDark,
    surface = NeutralDarkCard,
    onSurface = TextPrimaryDark,
    surfaceVariant = NeutralDarkSurface,
    onSurfaceVariant = TextSecondaryDark,
    outline = Color(0xFF4A3C3B)
)

private val LightColorScheme = lightColorScheme(
    primary = BiteBoxRed,
    onPrimary = Color.White,
    primaryContainer = BiteBoxRedContainer,
    onPrimaryContainer = OnBiteBoxRedContainer,
    secondary = BiteBoxMustardDark,
    onSecondary = Color.White,
    secondaryContainer = BiteBoxMustardContainer,
    onSecondaryContainer = OnBiteBoxMustardContainer,
    tertiary = BiteBoxMustard,
    onTertiary = Color.Black,
    background = NeutralLight,
    onBackground = TextPrimaryLight,
    surface = NeutralLightCard,
    onSurface = TextPrimaryLight,
    surfaceVariant = NeutralLightSurface,
    onSurfaceVariant = TextSecondaryLight,
    outline = Color(0xFFE5DDD8)
)

@Composable
fun BiteBoxTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
