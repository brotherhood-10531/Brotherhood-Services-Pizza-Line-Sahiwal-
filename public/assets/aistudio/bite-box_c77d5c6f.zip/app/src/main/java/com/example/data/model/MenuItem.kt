package com.example.data.model

import androidx.annotation.DrawableRes

enum class MenuCategory(val displayName: String) {
    ALL("All"),
    BURGERS("Burgers"),
    WRAPS("Wraps"),
    LOADED_FRIES("Loaded Fries"),
    COMBOS("Deals & Combos"),
    DESSERTS("Desserts & Drinks")
}

data class MenuItem(
    val id: String,
    val name: String,
    val category: MenuCategory,
    val description: String,
    val price: Int,
    @DrawableRes val drawableRes: Int,
    val badge: String? = null,
    val rating: Float = 4.8f,
    val reviewCount: Int = 120,
    val calories: String = "550 kcal",
    val isChefPick: Boolean = false,
    val story: String? = null
)

data class ComboDeal(
    val id: String,
    val title: String,
    val itemsSummary: String,
    val originalPrice: Int,
    val dealPrice: Int,
    val discountTag: String,
    @DrawableRes val drawableRes: Int,
    val description: String
)

data class Testimonial(
    val id: String,
    val name: String,
    val area: String,
    val rating: Float,
    val comment: String,
    val date: String
)

data class GalleryItem(
    val id: String,
    val title: String,
    val category: String,
    @DrawableRes val drawableRes: Int,
    val caption: String
)

data class CartItem(
    val menuItem: MenuItem,
    val quantity: Int = 1,
    val extraCheese: Boolean = false,
    val extraJalapeno: Boolean = false,
    val upgradeMeal: Boolean = false,
    val specialInstructions: String = ""
) {
    val unitPrice: Int
        get() {
            var price = menuItem.price
            if (extraCheese) price += 120
            if (extraJalapeno) price += 80
            if (upgradeMeal) price += 320
            return price
        }

    val totalPrice: Int
        get() = unitPrice * quantity
}
