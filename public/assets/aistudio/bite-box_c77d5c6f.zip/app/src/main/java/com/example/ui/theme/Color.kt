package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Fast Food Crimson / Dark Red Palette
val BiteBoxRed = Color(0xFF991B1B)
val BiteBoxRedDark = Color(0xFF7F1D1D)
val BiteBoxRedLight = Color(0xFFDC2626)
val BiteBoxRedContainer = Color(0xFFFEE2E2)
val OnBiteBoxRedContainer = Color(0xFF7F1D1D)

// Secondary Mustard / Golden Amber Palette
val BiteBoxMustard = Color(0xFFF59E0B)
val BiteBoxMustardDark = Color(0xFFD97706)
val BiteBoxMustardLight = Color(0xFFFDE68A)
val BiteBoxMustardContainer = Color(0xFFFEF3C7)
val OnBiteBoxMustardContainer = Color(0xFF78350F)

// Accent & Neutral Palette
val NeutralDark = Color(0xFF181110)
val NeutralDarkCard = Color(0xFF231A19)
val NeutralDarkSurface = Color(0xFF2C2220)
val NeutralLight = Color(0xFFFDFBF7)
val NeutralLightCard = Color(0xFFFFFFFF)
val NeutralLightSurface = Color(0xFFF6F1EA)

val TextPrimaryLight = Color(0xFF1F1514)
val TextSecondaryLight = Color(0xFF6B5E5C)
val TextPrimaryDark = Color(0xFFFAF1F0)
val TextSecondaryDark = Color(0xFFAFA2A0)

// Status Colors
val StatusOpenGreen = Color(0xFF16A34A)
val StatusClosedRed = Color(0xFFDC2626)
val RatingGold = Color(0xFFEAB308)
