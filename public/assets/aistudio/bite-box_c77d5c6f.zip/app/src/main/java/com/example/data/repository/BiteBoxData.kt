package com.example.data.repository

import android.net.Uri
import com.example.R
import com.example.data.model.ComboDeal
import com.example.data.model.GalleryItem
import com.example.data.model.MenuCategory
import com.example.data.model.MenuItem
import com.example.data.model.Testimonial
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.LocalTime
import java.time.ZoneId

object BiteBoxData {
    const val CAFE_NAME = "Bite Box"
    const val TAGLINE = "Fresh. Fast. Flavorful."
    const val LOCATION = "F-7 Markaz, Islamabad, Pakistan"
    const val PHONE_NUMBER = "+923112233444"
    const val WHATSAPP_ORDER_NUMBER = "923140607452"
    const val WHATSAPP_CUSTOMER_CARE = "923112233444"
    const val EMAIL = "contact@bitebox.pk"
    const val HOURS = "12 PM – 12 AM (Mon–Sun)"
    const val MAPS_QUERY = "F-7 Markaz, Islamabad, Pakistan"
    const val MAPS_URL = "https://maps.google.com/?q=F-7+Markaz+Islamabad+Pakistan"

    fun isStoreOpen(): Boolean {
        return try {
            val pktZone = ZoneId.of("Asia/Karachi")
            val now = LocalTime.now(pktZone)
            // 12 PM (12:00) to 12 AM (23:59:59)
            val openTime = LocalTime.of(12, 0)
            now >= openTime
        } catch (_: Exception) {
            true
        }
    }

    fun buildWhatsAppItemUrl(itemName: String, price: Int): String {
        val message = "Hi Bite Box! I want to order a $itemName (Rs. $price). Please confirm availability and delivery time."
        val encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
        return "https://wa.me/$WHATSAPP_ORDER_NUMBER?text=$encoded"
    }

    fun buildWhatsAppGeneralUrl(customMessage: String): String {
        val encoded = URLEncoder.encode(customMessage, StandardCharsets.UTF_8.toString())
        return "https://wa.me/$WHATSAPP_ORDER_NUMBER?text=$encoded"
    }

    val menuItems = listOf(
        MenuItem(
            id = "m1",
            name = "Crispy Zinger Burger",
            category = MenuCategory.BURGERS,
            description = "Crispy golden spiced fried chicken breast filet, garlic mayonnaise, fresh iceberg lettuce, toasted butter brioche bun.",
            price = 690,
            drawableRes = R.drawable.img_crispy_zinger,
            badge = "Bestseller",
            rating = 4.9f,
            reviewCount = 342,
            calories = "620 kcal",
            isChefPick = true,
            story = "Marinated for 14 hours in our Islamabad secret blend of 11 herbs & spices, coated with hand-flaked batter and flash-fried to juicy perfection."
        ),
        MenuItem(
            id = "m2",
            name = "Beef Cheese Burger",
            category = MenuCategory.BURGERS,
            description = "Double smashed 100% prime beef patties, molten cheddar slice, caramelized onions, dill pickles, signature Bite Box red relish.",
            price = 850,
            drawableRes = R.drawable.img_hero_burger,
            badge = "Chef's Special",
            rating = 4.95f,
            reviewCount = 289,
            calories = "740 kcal",
            isChefPick = true,
            story = "Crafted from daily fresh minced beef grilled over high heat on a custom flat top to seal in every drop of rich natural savoriness."
        ),
        MenuItem(
            id = "m3",
            name = "Signature Loaded Fries",
            category = MenuCategory.LOADED_FRIES,
            description = "Jumbo golden crinkle fries smothered in cheddar cheese lava, spicy jalapeno coins, crispy bits, and secret spicy sauce.",
            price = 550,
            drawableRes = R.drawable.img_loaded_fries,
            badge = "Must Try",
            rating = 4.85f,
            reviewCount = 410,
            calories = "590 kcal",
            isChefPick = true,
            story = "The crowd favorite of F-7 Markaz foodies. Double-fried for maximum crunch, crowned with our house-blended molten cheese sauce."
        ),
        MenuItem(
            id = "m4",
            name = "Shawarma Wrap Royale",
            category = MenuCategory.WRAPS,
            description = "Thinly shaved marinated chicken breast, authentic Lebanese toum garlic cream, pickled gherkins, wrapped in warm pita.",
            price = 590,
            drawableRes = R.drawable.img_crispy_zinger,
            badge = "Popular",
            rating = 4.75f,
            reviewCount = 195,
            calories = "480 kcal"
        ),
        MenuItem(
            id = "m5",
            name = "Double Trouble Smash",
            category = MenuCategory.BURGERS,
            description = "Two beef patties with crispy grilled edges, double sharp American cheese, crispy fried onion straws, BBQ aioli.",
            price = 980,
            drawableRes = R.drawable.img_hero_burger,
            badge = "Heavy Hitter",
            rating = 4.9f,
            reviewCount = 152,
            calories = "830 kcal"
        ),
        MenuItem(
            id = "m6",
            name = "Fiery Buffalo Chicken Wrap",
            category = MenuCategory.WRAPS,
            description = "Crispy chicken tenders tossed in tangy cayenne buffalo glaze with buttermilk ranch slaw in a toasted tortilla.",
            price = 620,
            drawableRes = R.drawable.img_crispy_zinger,
            badge = "Hot & Spicy",
            rating = 4.8f,
            reviewCount = 114,
            calories = "510 kcal"
        ),
        MenuItem(
            id = "m7",
            name = "Chili Cheesy Curly Fries",
            category = MenuCategory.LOADED_FRIES,
            description = "Seasoned spiral curly fries loaded with melted pepper jack cheese, chopped green chilies, and tangy ranch drizzle.",
            price = 580,
            drawableRes = R.drawable.img_loaded_fries,
            badge = "Spicy",
            rating = 4.7f,
            reviewCount = 98,
            calories = "520 kcal"
        ),
        MenuItem(
            id = "m8",
            name = "Choco Lava Cake",
            category = MenuCategory.DESSERTS,
            description = "Warm Belgian chocolate molten cake with a decadent flowing chocolate center, dusted with powdered sugar.",
            price = 450,
            drawableRes = R.drawable.img_combo_deal,
            badge = "Sweet Tooth",
            rating = 4.9f,
            reviewCount = 168,
            calories = "410 kcal"
        ),
        MenuItem(
            id = "m9",
            name = "Lotus Biscoff Thickshake",
            category = MenuCategory.DESSERTS,
            description = "Creamy handcrafted milkshake blended with Belgian speculoos cookie butter, whipped topping, and crushed biscuits.",
            price = 490,
            drawableRes = R.drawable.img_combo_deal,
            badge = "Top Rated",
            rating = 4.92f,
            reviewCount = 205,
            calories = "460 kcal"
        ),
        MenuItem(
            id = "m10",
            name = "Bite Box Crispy Strips (5 pcs)",
            category = MenuCategory.BURGERS,
            description = "Tender whole chicken tenderloins battered in crisp golden breading, served with signature honey-mustard dip.",
            price = 520,
            drawableRes = R.drawable.img_crispy_zinger,
            badge = "Snack Favorite",
            rating = 4.8f,
            reviewCount = 135,
            calories = "450 kcal"
        ),
        MenuItem(
            id = "m11",
            name = "Truffle Mushroom Swiss Burger",
            category = MenuCategory.BURGERS,
            description = "Prime beef patty topped with sautéed wild button mushrooms, rich Swiss cheese slice, and garlic truffle mayo.",
            price = 920,
            drawableRes = R.drawable.img_hero_burger,
            badge = "Gourmet",
            rating = 4.88f,
            reviewCount = 89,
            calories = "710 kcal"
        ),
        MenuItem(
            id = "m12",
            name = "Peri-Peri Masala Fries",
            category = MenuCategory.LOADED_FRIES,
            description = "Classic skin-on french fries tossed in zesty crushed African bird's eye chili and Himalayan pink salt.",
            price = 350,
            drawableRes = R.drawable.img_loaded_fries,
            badge = "Crispy",
            rating = 4.65f,
            reviewCount = 176,
            calories = "340 kcal"
        )
    )

    val comboDeals = listOf(
        ComboDeal(
            id = "c1",
            title = "Duo Crunch Feast",
            itemsSummary = "2x Crispy Zingers + 1x Large Loaded Fries + 2x Drinks",
            originalPrice = 2150,
            dealPrice = 1650,
            discountTag = "SAVE 25%",
            drawableRes = R.drawable.img_combo_deal,
            description = "The ultimate pair feast! Two crunchy zinger burgers with full-loaded cheese fries and two ice-cold sodas."
        ),
        ComboDeal(
            id = "c2",
            title = "Bite Box Mega Squad (4 Pax)",
            itemsSummary = "2x Beef Burgers + 2x Zingers + 2x Loaded Fries + 4x Drinks",
            originalPrice = 4200,
            dealPrice = 3250,
            discountTag = "FAMILY SAVER",
            drawableRes = R.drawable.img_hero_burger,
            description = "Ideal for friends & families visiting F-7 Markaz or ordering late-night movie boxes to their doorstep."
        ),
        ComboDeal(
            id = "c3",
            title = "Solo Power Box",
            itemsSummary = "1x Beef Smash Burger + Crinkle Fries + Choco Lava Cake + Drink",
            originalPrice = 1650,
            dealPrice = 1290,
            discountTag = "BESTSELLER",
            drawableRes = R.drawable.img_loaded_fries,
            description = "Complete gourmet meal for one! Gourmet smash patty with golden crispy fries and a decadent warm lava cake."
        ),
        ComboDeal(
            id = "c4",
            title = "Late Night Munchies",
            itemsSummary = "1x Shawarma Wrap + 1x Loaded Fries + Lotus Biscoff Shake",
            originalPrice = 1630,
            dealPrice = 1299,
            discountTag = "NIGHT SPECIAL",
            drawableRes = R.drawable.img_crispy_zinger,
            description = "Available until 12 AM midnight. Savor our tender shawarma wrap, loaded cheese fries, and thick biscoff shake."
        )
    )

    val testimonials = listOf(
        Testimonial(
            id = "t1",
            name = "Hamza Farooq",
            area = "F-7/2, Islamabad",
            rating = 5.0f,
            comment = "Easily the best beef burger in Islamabad! Smashed crust is unbelievable and the loaded fries stay crispy even for home delivery.",
            date = "2 days ago"
        ),
        Testimonial(
            id = "t2",
            name = "Ayesha Malik",
            area = "G-11 Markaz",
            rating = 5.0f,
            comment = "Ordered via WhatsApp for our office team lunch. Hot food arrived in 25 mins sharp, packaging is top notch and the zinger is huge!",
            date = "Last week"
        ),
        Testimonial(
            id = "t3",
            name = "Saad Qureshi",
            area = "E-7, Islamabad",
            rating = 4.9f,
            comment = "Bite Box in F-7 is our regular weekend spot now. Their secret spicy sauce is unlike anything else in the twin cities. 10/10 recommended!",
            date = "3 weeks ago"
        )
    )

    val galleryItems = listOf(
        GalleryItem(
            id = "g1",
            title = "Signature Gourmet Smash",
            category = "Burgers",
            drawableRes = R.drawable.img_hero_burger,
            caption = "Double beef smashed patty with molten cheddar and caramelized onions fresh off the grill."
        ),
        GalleryItem(
            id = "g2",
            title = "Molten Cheddar Loaded Fries",
            category = "Sides",
            drawableRes = R.drawable.img_loaded_fries,
            caption = "Crinkle-cut potatoes soaked in cheddar sauce with jalapeño peppers and spicy drizzle."
        ),
        GalleryItem(
            id = "g3",
            title = "Weekend Mega Combo Spread",
            category = "Combos",
            drawableRes = R.drawable.img_combo_deal,
            caption = "Full feast setup ready for dine-in and takeaway at F-7 Markaz, Islamabad."
        ),
        GalleryItem(
            id = "g4",
            title = "Triple-Dredged Golden Zinger",
            category = "Burgers",
            drawableRes = R.drawable.img_crispy_zinger,
            caption = "Fried golden crispy chicken breast filet served in toasted sesame brioche."
        ),
        GalleryItem(
            id = "g5",
            title = "Choco Lava Cake & Thickshakes",
            category = "Desserts",
            drawableRes = R.drawable.img_combo_deal,
            caption = "Sweet tooth cravings satisfied with Belgian molten chocolate and artisanal shakes."
        ),
        GalleryItem(
            id = "g6",
            title = "Party Box Catering Orders",
            category = "Combos",
            drawableRes = R.drawable.img_hero_burger,
            caption = "Custom packed event meals for birthdays, college gatherings, and corporate events."
        )
    )
}
