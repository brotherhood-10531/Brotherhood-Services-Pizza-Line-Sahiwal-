package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CartItem
import com.example.data.model.ComboDeal
import com.example.data.model.GalleryItem
import com.example.data.model.MenuItem
import com.example.data.repository.BiteBoxData
import com.example.ui.components.BiteBoxBottomBar
import com.example.ui.components.BiteBoxTab
import com.example.ui.components.BiteBoxTopBar
import com.example.ui.components.CartBottomSheet
import com.example.ui.components.ItemDetailDialog
import com.example.ui.components.LightboxDialog
import com.example.ui.screens.CateringScreen
import com.example.ui.screens.ContactScreen
import com.example.ui.screens.DealsScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.theme.BiteBoxRed
import com.example.ui.theme.BiteBoxTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BiteBoxTheme {
                BiteBoxApp()
            }
        }
    }
}

@Composable
fun BiteBoxApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by remember { mutableStateOf(BiteBoxTab.HOME) }
    val cartItems = remember { mutableStateListOf<CartItem>() }

    var selectedItemForDetail by remember { mutableStateOf<MenuItem?>(null) }
    var selectedGalleryItem by remember { mutableStateOf<GalleryItem?>(null) }
    var showCartSheet by remember { mutableStateOf(false) }

    // Helper functions for Intents
    fun launchUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchDialer(phone: String) {
        try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Could not launch phone dialer", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchWhatsApp(customMessage: String) {
        val url = BiteBoxData.buildWhatsAppGeneralUrl(customMessage)
        launchUrl(url)
    }

    fun launchMaps() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:33.7206,73.0538?q=${Uri.encode(BiteBoxData.MAPS_QUERY)}"))
            context.startActivity(intent)
        } catch (_: Exception) {
            launchUrl(BiteBoxData.MAPS_URL)
        }
    }

    // Predictive Back Handling
    BackHandler(enabled = showCartSheet || selectedItemForDetail != null || selectedGalleryItem != null || currentTab != BiteBoxTab.HOME) {
        when {
            showCartSheet -> showCartSheet = false
            selectedItemForDetail != null -> selectedItemForDetail = null
            selectedGalleryItem != null -> selectedGalleryItem = null
            currentTab != BiteBoxTab.HOME -> currentTab = BiteBoxTab.HOME
        }
    }

    Scaffold(
        topBar = {
            BiteBoxTopBar(
                cartCount = cartItems.sumOf { it.quantity },
                onOpenCart = { showCartSheet = true },
                onCallClick = { launchDialer(BiteBoxData.PHONE_NUMBER) },
                onWhatsAppClick = {
                    launchWhatsApp("Hi Bite Box! I would like to place an order or ask a question.")
                }
            )
        },
        bottomBar = {
            BiteBoxBottomBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        },
        floatingActionButton = {
            if (cartItems.isNotEmpty() && !showCartSheet) {
                FloatingActionButton(
                    onClick = { showCartSheet = true },
                    containerColor = BiteBoxRed,
                    contentColor = Color.White,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier.testTag("floating_cart_fab")
                ) {
                    BadgedBox(
                        badge = {
                            Badge(
                                containerColor = Color(0xFFF59E0B),
                                contentColor = Color.Black
                            ) {
                                Text(
                                    text = cartItems.sumOf { it.quantity }.toString(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = "Open Cart",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            } else if (!showCartSheet) {
                FloatingActionButton(
                    onClick = {
                        launchWhatsApp("Hi Bite Box! I want to order from F-7 Markaz, Islamabad.")
                    },
                    containerColor = Color(0xFF25D366),
                    contentColor = Color.White,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    modifier = Modifier.testTag("floating_whatsapp_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "Chat on WhatsApp",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentTab, label = "TabTransition") { tab ->
                when (tab) {
                    BiteBoxTab.HOME -> {
                        HomeScreen(
                            onNavigateTab = { currentTab = it },
                            onItemClick = { selectedItemForDetail = it },
                            onDirectWhatsAppOrder = { item ->
                                launchUrl(BiteBoxData.buildWhatsAppItemUrl(item.name, item.price))
                            },
                            onComboOrder = { deal ->
                                val msg = "Hi Bite Box! I want to order the *${deal.title}* (${deal.itemsSummary}) for Rs. ${deal.dealPrice}."
                                launchWhatsApp(msg)
                            },
                            onGalleryItemClick = { selectedGalleryItem = it },
                            onCallClick = { launchDialer(BiteBoxData.PHONE_NUMBER) },
                            onWhatsAppClick = { msg -> launchWhatsApp(msg) },
                            onMapsClick = { launchMaps() },
                            onSocialClick = { url -> launchUrl(url) }
                        )
                    }

                    BiteBoxTab.MENU -> {
                        MenuScreen(
                            onItemClick = { selectedItemForDetail = it },
                            onDirectWhatsAppOrder = { item ->
                                launchUrl(BiteBoxData.buildWhatsAppItemUrl(item.name, item.price))
                            }
                        )
                    }

                    BiteBoxTab.DEALS -> {
                        DealsScreen(
                            onComboOrder = { deal ->
                                val msg = "Hi Bite Box! I want to order the *${deal.title}* (${deal.itemsSummary}) for Rs. ${deal.dealPrice}."
                                launchWhatsApp(msg)
                            },
                            onCustomInquiry = { inquiry -> launchWhatsApp(inquiry) }
                        )
                    }

                    BiteBoxTab.GALLERY -> {
                        GalleryScreen(
                            onItemClick = { selectedGalleryItem = it }
                        )
                    }

                    BiteBoxTab.CATERING -> {
                        CateringScreen(
                            onRequestQuoteWhatsApp = { quoteMsg -> launchWhatsApp(quoteMsg) }
                        )
                    }

                    BiteBoxTab.CONTACT -> {
                        ContactScreen(
                            onCallClick = { launchDialer(BiteBoxData.PHONE_NUMBER) },
                            onWhatsAppClick = { msg -> launchWhatsApp(msg) },
                            onMapsClick = { launchMaps() },
                            onSocialClick = { url -> launchUrl(url) }
                        )
                    }
                }
            }
        }
    }

    // Item Detail & Customization Modal
    if (selectedItemForDetail != null) {
        ItemDetailDialog(
            item = selectedItemForDetail,
            onDismiss = { selectedItemForDetail = null },
            onAddToCart = { cartItem ->
                // Check if identical item already in cart
                val existingIndex = cartItems.indexOfFirst {
                    it.menuItem.id == cartItem.menuItem.id &&
                            it.extraCheese == cartItem.extraCheese &&
                            it.extraJalapeno == cartItem.extraJalapeno &&
                            it.upgradeMeal == cartItem.upgradeMeal &&
                            it.specialInstructions == cartItem.specialInstructions
                }
                if (existingIndex >= 0) {
                    val existing = cartItems[existingIndex]
                    cartItems[existingIndex] = existing.copy(quantity = existing.quantity + cartItem.quantity)
                } else {
                    cartItems.add(cartItem)
                }
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Added ${cartItem.menuItem.name} to your order!")
                }
            },
            onDirectWhatsAppOrder = { item, cartItem ->
                val extras = mutableListOf<String>()
                if (cartItem.extraCheese) extras.add("Extra Molten Cheddar")
                if (cartItem.extraJalapeno) extras.add("Pickled Jalapeños")
                if (cartItem.upgradeMeal) extras.add("Combo Meal (Fries+Drink)")
                if (cartItem.specialInstructions.isNotBlank()) extras.add("Note: ${cartItem.specialInstructions}")

                val extrasText = if (extras.isNotEmpty()) " with [${extras.joinToString(", ")}]" else ""
                val msg = "Hi Bite Box! I want to order ${cartItem.quantity}x *${item.name}*$extrasText (Total: Rs. ${cartItem.totalPrice}). Please confirm availability."
                launchWhatsApp(msg)
            }
        )
    }

    // Lightbox Modal for Gallery Images
    if (selectedGalleryItem != null) {
        LightboxDialog(
            item = selectedGalleryItem,
            onDismiss = { selectedGalleryItem = null },
            onOrderClick = { galleryItem ->
                val msg = "Hi Bite Box! I loved the photo of *${galleryItem.title}* from your gallery. How can I order this?"
                launchWhatsApp(msg)
            }
        )
    }

    // Slide-up Cart Bottom Sheet
    if (showCartSheet) {
        CartBottomSheet(
            cartItems = cartItems,
            onDismiss = { showCartSheet = false },
            onUpdateQuantity = { index, newQty ->
                if (index in cartItems.indices) {
                    cartItems[index] = cartItems[index].copy(quantity = newQty)
                }
            },
            onRemoveItem = { index ->
                if (index in cartItems.indices) {
                    cartItems.removeAt(index)
                }
            },
            onClearCart = {
                cartItems.clear()
            },
            onCheckoutWhatsApp = { orderMessage ->
                launchWhatsApp(orderMessage)
            }
        )
    }
}
